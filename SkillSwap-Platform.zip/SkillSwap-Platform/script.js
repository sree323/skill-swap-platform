const searchInput = document.getElementById('searchInput');
const skillCards = [...document.querySelectorAll('.skill-card')];
const emptyState = document.getElementById('emptyState');

searchInput.addEventListener('input', () => {
  const query = searchInput.value.trim().toLowerCase();
  let visible = 0;
  skillCards.forEach(card => {
    const text = (card.dataset.search + ' ' + card.innerText).toLowerCase();
    const match = text.includes(query);
    card.hidden = !match;
    if (match) visible++;
  });
  emptyState.hidden = visible !== 0;
});

document.querySelectorAll('.learn-btn').forEach(button => {
  button.addEventListener('click', () => {
    const skill = button.dataset.skill;
    document.getElementById('learn').value = skill;
    document.getElementById('join').scrollIntoView({ behavior: 'smooth' });
    document.getElementById('name').focus({ preventScroll: true });
  });
});

document.getElementById('joinForm').addEventListener('submit', event => {
  event.preventDefault();
  const entry = {
    name: document.getElementById('name').value.trim(),
    email: document.getElementById('email').value.trim(),
    teach: document.getElementById('teach').value.trim(),
    learn: document.getElementById('learn').value.trim(),
    submittedAt: new Date().toISOString()
  };
  const entries = JSON.parse(localStorage.getItem('skillswapEntries') || '[]');
  entries.push(entry);
  localStorage.setItem('skillswapEntries', JSON.stringify(entries));
  document.getElementById('formMessage').textContent =
    'Thank you, ' + entry.name + '! Your demo entry has been saved in this browser.';
  event.target.reset();
});
