# SkillSwap Platform

**Developed by:** Sree Varsan  
**Course:** B.Sc. Computer Science and Data Analytics

## Project Description
SkillSwap is a responsive web-based skill exchange platform concept. It helps people discover skills, share what they can teach, and express interest in learning from others.

## Technologies Used
- HTML5
- CSS3
- JavaScript

## Features
- Responsive landing page
- Skill cards for different learning topics
- Search and filter skills
- Interest buttons that fill the learning field
- Join form with basic input validation
- Demo form entries saved in browser local storage

## How to Run
1. Download or clone this repository.
2. Open the project folder.
3. Open `index.html` in a modern web browser.

No build tools or installation are required.

## Project Structure
- `index.html` – page structure and content
- `style.css` – layout, colours and responsive styling
- `script.js` – search, interest buttons and demo form interaction

## Note
This is an academic front-end prototype. The form stores demo entries only in the current browser using local storage. It does not send data to a server or provide real user accounts.

## Author
Sree Varsan  
B.Sc. Computer Science and Data Analytics
